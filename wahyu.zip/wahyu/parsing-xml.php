<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parsing</title>
</head>
<body>
    <h1>parsing</h1>

    <?php
$myXMLData =
"<?xml version='1.0'?>
<moleculedb>
<molecule name='Benzine'>
<symbol>ben</symbol>
<code>A</code>
</molecule>
<molecule name='Water'>
<symbol>h2o</symbol>
<code>K</code>
</molecule>
</moleculedb>";

$xml=simplexml_load_string($myXMLData) or die("Error: Cannot create object");
$parseXml = json_decode($xml, true);
foreach ($parseXml as $key => $value) {
    print_r($value);
}
?>
</body>
</html>